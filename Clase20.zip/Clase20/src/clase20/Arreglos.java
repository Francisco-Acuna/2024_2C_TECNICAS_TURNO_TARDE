

package clase20;


public class Arreglos {
    public static void main(String[] args) {
        //si tuviera que guardar varios valores enteros en variables
        int numero1 = 12;
        int numero2 = 44;
        int numero3 = 67;
        int numero4 = 90;
        
        /*
        Podría generar un conjunto de variables que tengan un mismo nombre
        que las agrupe a todas.
        Podemos acceder a cada variable por medio del índice.
        Recordemos que los índices comienzan en cero.
        Optimizamos la lectura de la información accediendo por un mismo nombre
        a distintas variables y no por nombre de cada una de ellas.
        */
        
        System.out.println("Arreglos, Arrays o vectores");
        
        /*
            tipo_de_dato[] identificador; -> declaración
            tipo_de_dato identificador[]; -> declaración
            identificador = new tipo_de_dato[n]; -> n es un número entero
            n representa la longitud del arreglo
            la longitud es la cantidad de elementos que va a tener el arreglo.
        */
        
        float[] temperaturas; // declaración
        temperaturas = new float[10]; // longitud de 10
        float temperaturas2[]; // declaración
        temperaturas2 = new float[12]; // longitud de 12
        String[] nombres = new String[5]; // longitud de 5
        //declaración y asignación de longitud
        
        
        //asignación de valores a las variables
        temperaturas[0] = 12.35f;
        temperaturas[1] = 22.45f;
        temperaturas[3] = 7;
//        temperaturas[2] = "pepe"; error, no puedo guardar otro tipo de dato

        nombres[3] = "Juan";
//        nombres[5] = "Miguel"; erorr, no existe el índice 5 para una longitud de 5

        //leer el contenido de un índice
        System.out.println(temperaturas[0]);
        System.out.println(temperaturas[1]);
        System.out.println(temperaturas[3]);
        System.out.println(temperaturas[2]);
        System.out.println(nombres[3]);

        //inicialización
        int[] numeros = {12, 59, 57, 129, 0};
        //declaración de vector junto con asignación de valor y definición de longitud
        
        
    }
}
