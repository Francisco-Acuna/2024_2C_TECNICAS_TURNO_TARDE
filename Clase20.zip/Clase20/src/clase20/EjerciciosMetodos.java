
package clase20;

import java.util.Scanner;


public class EjerciciosMetodos {


    public static void main(String[] args) {
        
        /*
        Ejercicios funciones:
        1. crear una función que devuelva la cantidad de vocales de una palabra
        2. crear una función que indique si un número es múltiplo de 3
        3. crear una función que aplique %50 de premio si el ingreso es de más de 35.000
        */
        
        //1. crear una función que devuelva la cantidad de vocales de una palabra
        Scanner teclado = new Scanner(System.in);
//        System.out.println("Por favor, ingrese una palabra:");
//        String palabra = teclado.nextLine();
//        int cantidadVocales = contarVocales(palabra);
//        System.out.println("La cantidad de vocales que tiene la palabra analizada "
//                + "es: " +cantidadVocales);
        
        // 2. crear una función que indique si un número es múltiplo de 3
//        System.out.println("Ingrese un número para saber si es múltiplo de 3:");
//        int numero = teclado.nextInt();
//        System.out.println("El resultado fue: " + esMultiploDeTres(numero));
        
        // 3. crear una función que aplique %50 de premio si el ingreso es de más de 35.000
//        System.out.println("Ingrese el monto para calcular el premio");
//        float ingreso = teclado.nextFloat();
//        float montoMinimo = 35000;
//        float porcentaje = 50;
//        float montoADevolver = aplicarPremio(ingreso, montoMinimo, porcentaje);
//        System.out.println("El monto a entregar es: " + montoADevolver);
        
        /*
        Ejercicios procedimientos:
        1. Crear un procedimiento que calcule el área del triángulo y lo informe 
        por pantalla
        2. Crear un procedimiento que muestre por pantalla el valor del IVA de un 
        producto ingresado como parámetro
	3. Crear un procedimiento que muestre por pantalla la cantidad de números 
        impares que ingresa el usuario y lo informe por pantalla	
        */
        
        //1. Crear un procedimiento que calcule el área del triángulo y lo informe 
        //por pantalla
//        System.out.println("Ingrese la base del triángulo:");
//        float baseTriangulo = teclado.nextFloat();
//        System.out.println("Ingrese la altura del triángulo:");
//        float alturaTriangulo = teclado.nextFloat();
//        calcularAreaTriangulo(baseTriangulo, alturaTriangulo);
        
        //2. Crear un procedimiento que muestre por pantalla el valor del IVA de un 
        //producto ingresado como parámetro
        
//        System.out.println("Ingrese el valor del producto para calcular el IVA:");
//        float valorProducto = teclado.nextFloat();
//        devolverMontoIva(valorProducto);
        
        //3. Crear un procedimiento que muestre por pantalla la cantidad de números 
        //impares que ingresa el usuario y lo informe por pantalla
        
//         contarCantidadNumerosImpares(teclado);
       
        /*
        Crear un programa que reciba 3 parámetros y calcule la suma, resta, 
        multiplicación, división y el resto de dos números con decimales. 
        Las consignas para lograrlo son:
        * Debe crear un procedimiento, que reciba los 3 parámetros: 2 números con
        decimales y el carácter de operación.
        * Debe crear las funciones de las operaciones que retornen un número con 
        decimales.
        * Debe mostrar por consola un mensaje que indique el resultado y la 
        operación realizada
        */
        System.out.println("Ingrese un número:");
        float primerNumero = teclado.nextFloat();
        System.out.println("Ingrese el segundo número:");
        float segundoNumero = teclado.nextFloat();
        System.out.println("Indique el operador para realizar el cálculo");
        char operador = teclado.next().charAt(0);
        resolverOperacionesAritmeticas(primerNumero, segundoNumero, operador);
        
    }// final del método main
    
    public static int contarVocales(String palabra){
        int contadorVocales = 0;
        for(int i=0; i<palabra.length(); i++){
            if(esVocal(palabra.toLowerCase().charAt(i))){
                contadorVocales++;
            }
        }
        return contadorVocales;
    }

    public static boolean esVocal(char letra) {
        return letra=='a' || letra=='e' || letra=='i' || letra=='o' || letra=='u' ||
                letra=='á' || letra=='é' || letra=='í' || letra=='ó' || letra=='ú' ||
                letra=='ü';
    }
    
    public static boolean esMultiploDeTres(int numero){
        return numero%3==0;
    }
    
    public static float aplicarPremio(float ingreso, float montoMinimo, float porcentaje){
        float montoFinal = ingreso;
        if(ingreso>montoMinimo){
            float montoAdicional = ingreso / 100 * porcentaje;
            montoFinal += montoAdicional;            
        }
        return montoFinal;
    }
    
    public static void calcularAreaTriangulo(float base, float altura){
        float area = (base * altura) / 2 ;
        System.out.println("El área del triángulo es: " + area);
    }
    
    public static void devolverMontoIva(float monto){
        final float IVA = 21;
        float montoDelIva = monto / 100 * IVA;
        System.out.println("El monto del IVA para el producto ingresado "
                + "es de: " + montoDelIva);
    }
    
    public static void contarCantidadNumerosImpares(Scanner lector){
        int cantidadNumerosImpares = 0;
        int numero;
        do {
            System.out.println("Ingrese un número válido o el cero para salir:");
            numero = lector.nextInt();
            if(numero%2!=0) cantidadNumerosImpares++;
            if(numero==0) System.out.println("Usted eligió salir.");
        } while (numero!=0);
        System.out.println("La cantidad de números impares fue de: " + cantidadNumerosImpares);
    }
    
    public static void resolverOperacionesAritmeticas(float numero1, float numero2,
            char operador){
        float resultado = 0;
        String mensaje = "";
        switch(operador){
            case '+': 
                resultado = sumar(numero1, numero2);
                mensaje = "La operación realizada fue suma :-)"; break;
            case '-':
                resultado = restar(numero1, numero2);
                mensaje = "La operación realizada fue resta :-)"; break;
            case '*':
                resultado = multiplicar(numero1, numero2);
                mensaje = "La operación realizada fue multiplicación :-)"; break;
            case '/':
                if(numero2==0){
                    mensaje = "No se puede dividir por cero, animal.";
                }else{
                    resultado = dividir(numero1, numero2);
                    mensaje = "La operación realizada fue división ;-)";
                }break;
            case '%':
                if(numero2==0){
                    mensaje = "No se puede dividir por cero, animal.";
                }else{
                    resultado = obtenerResto(numero1, numero2);
                    mensaje = "La operación realizada fue módulo de la división ;-)";
                }break;
            default:
                mensaje = "El operador no es válido.";
        }
        System.out.println("El resultado fue: " + resultado);
        System.out.println(mensaje);
    }
    
    public static float sumar(float numero1, float numero2){
        return numero1 + numero2;
    }
    
    public static float restar(float numero1, float numero2){
        return numero1 - numero2;
    }
    
    public static float multiplicar(float numero1, float numero2){
        return numero1 * numero2;
    }
    
    public static float dividir(float numero1, float numero2){
        return numero1 / numero2;
    }
    
    public static float obtenerResto(float numero1, float numero2){
        return numero1 % numero2;
    }
    
    
    
}
