
package clase15;

import java.util.Scanner;


public class Clase15 {

    
    public static void main(String[] args) {
        /*
        1) Una tienda ofrece un descuento del 15% sobre el total de la compra 
        durante el mes de octubre. Dado un mes y un importe, calcular cu�l es 
        la cantidad que se debe cobrar al cliente.
        */
        
        Scanner teclado = new Scanner(System.in);
        
        
//        System.out.println("Introduce el mes (del 1 al 12)");
//        int mes = teclado.nextInt();
//        System.out.print("Introduce el importe total de la compra\n$");
//        double importe = teclado.nextDouble();
//        double totalAPagar = importe;
//        double descuento = 15;
//        
//        if(mes==10){
//            totalAPagar = importe - (importe/100*descuento);
//            System.out.println("El porcentaje de descuento es %" + descuento);
//        }else{
//            totalAPagar = importe;
//        }
//        
//        
//        String totalAPagarRedondeado = String.format("%.2f", totalAPagar);
//        
//        System.out.println("El total a cobrar al cliente es: $" + totalAPagarRedondeado);
        
        /*
        2) Crear un programa que pida al usuario un n�mero y un s�mbolo, y 
        dibuje un cuadrado usando ese s�mbolo. El cuadrado tendr� el tama�o 
        que ha indicado el usuario. Por ejemplo, si el usuario introduce 4 
        como tama�o y * como s�mbolo, deber� escribirse algo como:
        ****
        ****
        ****
        ****

        */

//        System.out.println("Introduce el tama�o del cuadrado: ");
//        int tamanio = teclado.nextInt();
//        System.out.println("Introduce el s�mbolo para dibujar el cuadrado");
//        String simbolo = teclado.next();
//        
//        for(int i=0; i<tamanio; i++){
//            for(int j=0; j<tamanio; j++){
//                System.out.print(simbolo);
//            }
//            System.out.println();
//        }
         

        /*
        3) Se pide representar el algoritmo que nos calcule la suma de los 
        N primeros n�meros naturales. N se leer� por teclado. Ejemplo, si 
        ingresamos 4, hacer: 1+2+3+4 = 10
        */
        
//        int suma = 0;
//        System.out.println("Ingrese un n�mero:");
//        int numero = teclado.nextInt();
//        
//        for(int i=1; i<=numero; i++){
//            suma += i;
//        }
//        
//        System.out.println("La suma total de los n�meros naturales es: " + suma);
        
        /*
        4) Crear un programa que visualice la cuenta de los n�meros que son 
        m�ltiplos de 2 o de 3 que hay entre 1 y 100.
        */
//        int contadorDeNumerosMultiplosDe2YDe3 = 0;
//        for(int i=1; i<=100; i++){
//            if(i%3==0 || i%2==0){
//                System.out.println(i);
//                contadorDeNumerosMultiplosDe2YDe3++;
//            }
//        }
//        
//        System.out.println("La cantidad de n�meros que son m�ltiplos de 2 o de 3"
//                + " que hay entre 1 y 100 son: " 
//                + contadorDeNumerosMultiplosDe2YDe3);

        /*
        5) Desarrollar un programa que permita ingresar un n�mero N. Acto 
        seguido, permitir ingresar N n�meros. La computadora muestra cu�l 
        fue el mayor y en qu� orden apareci�. Ejemplo: Se ingresa 5, luego 
        4 8 6 7 5, la computadora muestra: "El mayor es el 8 en la 2� posici�n".
        */
        
        
//        System.out.println("Cu�ntos n�meros desea ingresar?");
//        int cantidadDeNumeros = teclado.nextInt();
//        int numeroGrande = Integer.MIN_VALUE;
//        int posicionGrande = 0;
//        for(int i=1; i<=cantidadDeNumeros; i++){
//            System.out.println("Ingrese un n�mero:");
//            int numeroNuevo = teclado.nextInt();
//            if(numeroNuevo > numeroGrande){
//                numeroGrande=numeroNuevo;
//                posicionGrande = i;
//            }
//        }
//        
//        System.out.println("El mayor n�mero es: " + numeroGrande + " en la " 
//                + posicionGrande + " posici�n.");
        
        /*
        6) Desarrollar un programa que permita ingresar un n�mero natural. La
        computadora muestra el factorial del n�mero. Ejemplo: Se ingresa 5, la
        computadora muestra: 120
        */

//        System.out.println("Por favor ingrese un n�mero natural");
//        int numeroNatural = teclado.nextInt();
//        int factorial = 1;
//        for(int i=1; i<=numeroNatural; i++){
//            factorial *= i;
//        }
//        System.out.println("El factorial del n�mero ingresado es " + factorial);

        /*
        7) Crear un algoritmo (y su correspondiente diagrama de flujo) que lea n�meros
        enteros hasta teclear 0, y nos muestre el m�ximo, el m�nimo (sin considerar el
        0) y la media (promedio) de todos ellos.
        */
        
        

    }
    
}
