

package curso.java.tecnicas.condicionales;

import java.util.Scanner;


public class EstructurasIf {
    public static void main(String[] args) {
        
        //estructuras condicionales
        
        //estructura if
        int num1 = 150;
        int num2 = 20;
        
        System.out.println("Estructura if");
        if(num1 > num2){
            System.out.println("El num1 es mayor al num2");
        }
        System.out.println("Fin de la estructura if");
        
        if(num1 != 20){
            System.out.println("El num1 no es igual a 20");
        }
        
        boolean log1 = false;
        
        if(!log1){ //los valores booleanos, no se comparan con true y false
            System.out.println("log1 es verdadera");
        }
        
        //if en l�nea
        if(num1 > 100 && num2 == 20) System.out.println("Imprimo en l�nea");
        //cuando se ejecutar� una �nica sentencia, podemos omitir las llaves
        //y escribir la sentencia en l�nea
        
        //si el cuerpo del if contiene varias sentencias, debemos colocar las llaves
        if("hola".contains("ola")){
            System.out.println("Hola contiene \"ola\"");
            num1 += 2;
            System.out.println("num1 ahora vale: " + num1);
        }
        
        System.out.println("\n**Estructura if-else**");
        
        if(num1 > num2){
            System.out.println("El num1 es mayor al num2");
        }else{
            System.out.println("El num1 no es mayor que el num2");
        }
        
        //el ejemplo anterior tambi�n se puede hacer en l�nea
        //siempre y cuando haya una sola sentencia por bloque
        if(num1 > num2) System.out.println("El num1 es mayor al num2");
        else System.out.println("El num1 no es mayor que el num2");
        
        System.out.println("\n**Estructura if-else if-else**");
        
        if(num1 >num2){
            System.out.println("El num1 es mayor al num2");
        }else if(num2 > num1){
            System.out.println("El num2 es mayor que el num1");
        }else{
            System.out.println("Ambos n�meros son iguales.");
        }

        System.out.println("\n**Estructura if-else anidado**");
        
        String usuario = "pepito";
        String clave = "1234";
        
        if(usuario.equals("pepito")){
            if(clave.equals("1234")){
                System.out.println("Bienvenido Pepito!");
            }else{
                System.out.println("Clave incorrecta");
            }
        }else{
            System.out.println("Usuario incorrecto");
        }
        
        int edad = 18;
        boolean tienePasaporte = true;
        
        if(tienePasaporte){
            if(edad >= 18){
                System.out.println("Usted puede viajar.");
            }else{
                System.out.println("Usted debe viajar acompa�ado de un mayor");
            }
        }else{
            System.out.println("Usted no puede viajar.");
        }
        
        System.out.println("**************************");
        System.out.println("\nBienvenido al sistema de jubilaciones");
        System.out.println(" P O R  F A V O R");
        String genero;
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Ingrese su edad:");
        edad = teclado.nextInt();
        teclado.nextLine();
        System.out.println("Ingrese su genero:");
        genero = teclado.nextLine();
        
        if(genero.equals("hombre")){
            if(edad >= 65){
                System.out.println("Usted ya se puede jubilar");
            }else{
                System.out.println("Usted es muy joven para jubilarse");
            }
        }else if(genero.equals("mujer")){
            if(edad >= 60){
                System.out.println("Usted ya se puede jubilar");
            }else{
                System.out.println("Usted es muy joven para jubilarse");
            }
        }else{
            System.out.println("Ingrese g�nero hombre o mujer para poder realizar la operaci�n");
        }
        
        if(
                genero.equals("hombre") && edad>=65 
                || 
                genero.equals("mujer") && edad>=60
                ){
            System.out.println("Usted ya se puede jubilar");
        }else{
            System.out.println("Usted no se pude jubilar");
        }
        
        
    }
}
