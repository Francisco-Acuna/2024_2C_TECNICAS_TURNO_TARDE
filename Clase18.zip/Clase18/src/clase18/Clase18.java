
package clase18;

import java.util.Scanner;


public class Clase18 {


    public static void main(String[] args) {
        
        System.out.println("Funciones y procedimientos");
        
        /*
        Las funciones y los procedimientos son un bloque de código que  
        contiene una o más instrucciones, al cual podemos invocar para 
        que sean ejecutadas. 
        Las funciones y los procedimientos nos ayudan a hacer que nuestro
        código sea más legible y que evitemos tener código duplicado.
        */
        
        System.out.println("Funciones");
        /*
        Las funciones siempre retornan un valor.
        En su declaración deben indicar qué tipo de valor retornan.
        En su cuerpo deben contener la sentencia return con el retorno
        del tipo de dato que se indicó en su cabecera.
        */
                         
        int numero = retornarNumeroDiez();
        System.out.println(numero);
        int segundoNumero = 30;
        int resultado = sumarDosNumerosEnteros(numero, segundoNumero);
        System.out.println(resultado);
        resultado = sumarDosNumerosEnteros(10, 20);
        System.out.println(resultado);
        resultado = sumarDosNumerosEnteros(retornarNumeroDiez(), 50);
        
        System.out.println(esPar(15));
        System.out.println(esPar(retornarNumeroDiez()));
        
        System.out.println("*****************************");
        System.out.println("Procedimientos");
        /*
        Los procedimientos no tienen un retorno.
        En su declaración deben llevar la palabra reservada void
        para indicar que no tienen un retorno.
        */
        
        saludar();
        
        Scanner teclado = new Scanner(System.in);
        System.out.println("Ingrese su nombre");
        String nombreUsuario = teclado.nextLine();
        saludarNombre(nombreUsuario);
        
        System.out.println("Ingrese la base del rectángulo");
        float base = teclado.nextFloat();
        System.out.println("Ingrese la altura del rectángulo");
        float altura = teclado.nextFloat();
        calcularAreaRectangulo(base, altura);
        System.out.println("El area del rectángulo es: " + calcularAreaRectangulo2(base, altura));
        
        System.out.println("Ingrese su nombre");
        nombreUsuario = teclado.next();
        System.out.println("Ingrese un número");
        numero=teclado.nextInt();
        System.out.println("Ingrese otro número");
        segundoNumero = teclado.nextInt();
        sumaParOImpar(numero, segundoNumero, nombreUsuario);
        
        
    }//fin del método main
    
    //Ejemplos de funciones
    public static int retornarNumeroDiez(){
        return 10;
    }
    
    public static int sumarDosNumerosEnteros(int numero1, int numero2){
        int suma = numero1 + numero2;
        return suma;
    }
    
    public static boolean esPar(int numero){
//        if(numero%2==0){
//            return true;
//        }else{
//            return false;
//        }
        return numero%2==0;        
    }
    
    //Ejemplos de procedimientos
    public static void saludar(){
        System.out.println("Hola Mundo!");
    }
    
    public static void saludarNombre(String nombre){
        System.out.println("Hola " + nombre);
    }
    
    public static void calcularAreaRectangulo(float base, float altura){
        float area = base * altura;
        System.out.println("El área del rectángulo es: " + area);
    }
    
    //mismo ejemplo que el anterior pero con función
    public static float calcularAreaRectangulo2(float base, float altura){
        float area = base * altura;
        return area;
    }
    
    /**
     * Este procedimiento saluda al nombre que se ingresó y realiza la suma
     * de los dos números enteros que se ingresaron como parámetro.
     * Informa luego si la suma dio par o impar
     * @param numero1
     * @param numero2
     * @param nombre (nombre del usuario)
     */
    public static void sumaParOImpar(int numero1, int numero2, String nombre){
        saludarNombre(nombre);
        if(esPar(sumarDosNumerosEnteros(numero1, numero2))){
            System.out.println("La suma es par");
        }else{
            System.out.println("La suma es impar");
        }
    }
    
    
}//fin de la clase
