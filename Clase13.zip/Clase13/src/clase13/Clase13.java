/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase13;

import java.util.Scanner;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        /*
        Imprimir los n�meros del 1 al 10, sin imprimir
        n�meros 2, 5 y 9, uno abajo del otro.
        */
        
//        for(int i=1; i<=10; i++){
//            if(i==2 || i==5 || i==9){
//                continue;
//            }
//            System.out.println(i);
//        }
        
//        for(int i=1; i<=10; i++){
//            if(i!=2 && i!=5 && i!=9) System.out.println(i);
//        }
        
        /*
        Imprimir los n�meros del 1 al 30 sin imprimir
        n�meros entre el 10 y el 20 uno abajo del otro
        */
        
//        for(int i=1; i<=30; i++){
//            if(i<=10 || i>=20){
//                System.out.println(i);
//            }
//        }

        /*
        Imprimir los n�meros del 1 al 10 salteando de
        a dos, uno abajo del otro.

        Imprimir los n�meros del 10 al 1, uno al lado
        del otro.
        
        Imprimir la suma de los n�meros impares del
        1 al 10.
        */
        
//        for(int i=1; i<=10; i+=2){
//            System.out.println(i);
//        }
       
//        for(int i=10; i>=1; i--){
//            System.out.print(i+" ");
//        }
        
//        int nroImpar = 0;
//        for(int i=0; i<=10; i++){
//            if(i%2!=0){
//                nroImpar+=i;
//            }
//        }
//        
//        System.out.println("La suma de todos los n�meros impares es: " + nroImpar);

        /*
        Una persona desea invertir $1000 en un banco, el
        cual le otorga un 2% de inter�s mensual �Cu�l
        ser� la cantidad de dinero que esta persona
        tendr� al cabo de un a�o?
        En el primer mes tendr� acumulado 1000 $ m�s
        20 $ de inter�s ( 2% de 1000 ). En el segundo
        mes se le sumar� un 2% a la base de 1020 $ del
        mes anterior y as� sucesivamente. 
        */

        double dinero = 1000;
        
        for(int i=1; i<=12; i++){
            dinero = dinero * 1.02;
        }

        System.out.println(dinero);
        
        System.out.println("\n*****************************\n");
        
        double capitalInicial = 1000;
        double montoAcumulado = capitalInicial;
        double interes = 2;
        int meses = 12;
        
        for(int i=1; i<=meses; i++){
            System.out.println("Su capital inicial para este mes es de $" + montoAcumulado);
            System.out.println("El inter�s en el mes " + i + " es del %" + interes);
            double interesMensual = montoAcumulado/100*interes;
            System.out.println("Que representa una ganancia de: $" + interesMensual);
            montoAcumulado += interesMensual;
            System.out.println("\n################################################\n");
        }

        System.out.println("Al finalizar el a�o, su capital ser� de: $" + 
                Math.round(montoAcumulado));
        
        /*
        Crear un programa que ingrese una oraci�n y
        muestre cu�l es el caracter que m�s se repite.
        Consideraciones
        * No debe incluir el espacio en blanco.
        * La oraci�n a ingresar no debe estar vac�a.
        */
        
        Scanner teclado = new Scanner(System.in);
        
        String oracion;
        
        //utilizamos do-while para asegurarnos de que se ingrese una oraci�n
        //que no est� vac�a
        do {
            System.out.println("Indique la oraci�n a evaluar, por favor no "
                    + "ingrese una oraci�n vac�a. Gracias.");
            oracion = teclado.nextLine();
            if(oracion.isBlank()){
                System.out.println("Usted es o se hace? Le acabo de decir que no est� vac�a!!!");
                System.out.println("Por favor ingrese nuevamente...");
            }
        } while (oracion.isBlank());
        
        //le damos un valor inicial con el primer caracter de la oraci�n
        char caracterMasRepetido = oracion.charAt(0);
        int cantidadDeRepeticiones = 0;
        
        //utilizamos la estructura for porque sabemos de antemano la cantidad de iteraciones
        for(int i=0; i<oracion.length(); i++){
            //almacenamos temporalmente el caracter actual del recorrido
            char caracter = oracion.charAt(i);
            
            //ignoramos los espacios en blanco
            if(caracter == ' ') continue;
            
            //creamos un contador parcial
            int recuento = 1;
            
            //contamos cu�ntas veces se repite el caracter en la oraci�n
            for(int j=i+1; j<oracion.length(); j++){
                if(oracion.charAt(j) == caracter) recuento++;
            }
            
            //comprobamos si es el caracter que m�s se repite hasta ahora
            //si lo es, reemplazamos los valores generales
            if(recuento > cantidadDeRepeticiones){
                cantidadDeRepeticiones = recuento;
                caracterMasRepetido = caracter;
            }     
        }
        
        
        System.out.println("El primer caracter que m�s se repite sin contar los espacios"
                + "es el \'" + caracterMasRepetido + "\' que se repite " + 
                cantidadDeRepeticiones + " veces.");
        
        
    }
    
}
