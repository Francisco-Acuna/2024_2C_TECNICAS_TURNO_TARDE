

package curso.java.tecnicas.condicionales;


public class EstructurasIf {
    public static void main(String[] args) {
        
        //estructuras condicionales
        
        //estructura if
        int num1 = 150;
        int num2 = 20;
        
        System.out.println("Estructura if");
        if(num1 > num2){
            System.out.println("El num1 es mayor al num2");
        }
        System.out.println("Fin de la estructura if");
        
        if(num1 != 20){
            System.out.println("El num1 no es igual a 20");
        }
        
        boolean log1 = false;
        
        if(!log1){ //los valores booleanos, no se comparan con true y false
            System.out.println("log1 es verdadera");
        }
        
        //if en l�nea
        if(num1 > 100 && num2 == 20) System.out.println("Imprimo en l�nea");
        //cuando se ejecutar� una �nica sentencia, podemos omitir las llaves
        //y escribir la sentencia en l�nea
        
        //si el cuerpo del if contiene varias sentencias, debemos colocar las llaves
        if("hola".contains("ola")){
            System.out.println("Hola contiene \"ola\"");
            num1 += 2;
            System.out.println("num1 ahora vale: " + num1);
        }
        
    }
}
