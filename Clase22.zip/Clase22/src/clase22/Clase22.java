
package clase22;

import java.util.Scanner;

public class Clase22 {

    public static void main(String[] args) {
        /*
        Crear un vector que contenga el monto de la facturación total de una empresa
        de los últimos 6 meses
        informar:
        la máxima facturación
        la facturación más baja
        el promedio de facturación
        */
        
        resolverEjercicio1();   
        
        /*
        Pedirle al usuario que ingrese el tamaño del vector (longitud)
        Luego pedirle al usuario que cargue los números de cada posición.
        Al finalizar, por pantalla mostrar:
            * Listado de números ingresados, uno al lado del otro separados por una barra.
            * Sumatoria de todos los números
            * Mayor número ingresado
            * Menor número ingresado
            * Promedio de números ingresados (entero, sin decimales)
            * Cantidad de números pares
            * Cantidad de números impares
        */

    }
    
    public static void resolverEjercicio1(){
        Scanner sc = new Scanner(System.in);
        float[] facturaciones = crearVectorFloat(sc, 6);
        float facturacionMaxima = obtenerMayorValor(facturaciones);
        float facturacionMinima = obtenerMenorValor(facturaciones);
        float facturacionPromedio = obtenerValorPromedio(facturaciones);
        System.out.println("********* Ejercicio 1 *********");
        System.out.println("La máxima facturación en la empresa en los últimos 6 meses es: $" + facturacionMaxima);
        System.out.println("La mínima facturación en la empresa en los últimos 6 meses es: $" + facturacionMinima);
        System.out.println("El promedio de la facturación de la empresa en los últimos 6 meses es: $" + facturacionPromedio);
        System.out.println("");
    }  
    
    public static float[] crearVectorFloat(Scanner sc, int longitud){
        float[] arreglo = new float[longitud];
        for(int i=0; i<longitud; i++){
            System.out.print("Ingrese el " + (i+1) + "° valor: $");
            arreglo[i] = sc.nextFloat();
        }
        return arreglo;
    }

    public static float obtenerMayorValor(float[] vector){
        float valorMaximo = vector[0];
        for(int i=0; i<vector.length; i++){
            if(vector[i]>valorMaximo) valorMaximo = vector[i];
        }
        return valorMaximo;
    }
    
    public static float obtenerMenorValor(float[] vector){
        float valorMinimo = vector[0];
        for(int i=0; i<vector.length; i++){
            if(vector[i]<valorMinimo) valorMinimo = vector[i];
        }
        return valorMinimo;
    }
    
    public static float obtenerValorPromedio(float[] vector){
        return sumatoria(vector) / vector.length;
    }
    
    public static float sumatoria(float[] vector){
        float sumatoria = 0;
        for(int i=0; i<vector.length; i++){
            sumatoria += vector[i];
        }
        return sumatoria;
    }
    
}
