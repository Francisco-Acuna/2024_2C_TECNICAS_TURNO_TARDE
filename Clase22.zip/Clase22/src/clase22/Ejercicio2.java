

package clase22;

import java.util.Scanner;


public class Ejercicio2 {
    public static void main(String[] args) {
        /*
        Pedirle al usuario que ingrese el tama�o del vector (longitud)
        Luego pedirle al usuario que cargue los n�meros de cada posici�n.
        Al finalizar, por pantalla mostrar:
            * Listado de n�meros ingresados, uno al lado del otro separados por una barra.
            * Sumatoria de todos los n�meros
            * Mayor n�mero ingresado
            * Menor n�mero ingresado
            * Promedio de n�meros ingresados (entero, sin decimales)
            * Cantidad de n�meros pares
            * Cantidad de n�meros impares
        */
        resolverSegundaConsigna();
    }
    
    public static void resolverSegundaConsigna(){
        Scanner teclado = new Scanner(System.in);
        int tamanioV;
        do {            
            System.out.println("Ingrese el tama�o del vector");
            tamanioV = teclado.nextInt();
        } while (tamanioV<=0);
        int[] facturaciones = new int[tamanioV];
        llenarValorVector(teclado, facturaciones);
        mostrarValores(facturaciones);
        int sumatoria = calcularSumaTotal(facturaciones);
        int mayor = encontrarMayor(facturaciones);
        int menor = encontrarMenor(facturaciones);
        int promedio = calcularPromedio(facturaciones);
        int pares = contarPares(facturaciones);
        int impares = contarImpares(facturaciones);
        System.out.println("La suma total de los montos es: " + sumatoria);
        System.out.println("El mayor monto ingresado es: " + mayor);
        System.out.println("El menor monto ingresado es: " + menor);
        System.out.println("El promedio de los montos ingresados es: " + promedio);
        System.out.println("La cantidad de n�meros pares es: " + pares);
        System.out.println("La cantidad de n�meros impares es: " + impares);
    }
    
    public static void llenarValorVector(Scanner teclado, int[] vector){
        for(int i=0; i<vector.length; i++){
            System.out.println("Ingrese el monto de la facuraci�n para el mes " + (i+1) + ": ");
            vector[i] = teclado.nextInt();
        }
    }
    
    public static void mostrarValores(int[] vector){
        System.out.println("Facturaci�n ingresada:");
        for(int i=0; i<vector.length;i++){
            if(i<vector.length -1) System.out.print(vector[i] + " | ");
            else System.out.println(vector[i]);
        }
    }
    
    public static int calcularSumaTotal(int[] vector){
        int suma = 0;
        for(int v:vector) suma+=v;
        return suma;
    }
    
    public static int encontrarMayor(int[] vector){
        int mayor = vector[0];
        for(int v:vector) if(v > mayor) mayor=v;
        return mayor;
    }
    
    public static int encontrarMenor(int[] vector){
        int menor = vector[0];
        for(int i=0; i<vector.length; i++){
            if(vector[i] < menor){
                menor=vector[i];
            }
        }
        return menor;
    }
    
    public static int calcularPromedio(int[] vector){
        return calcularSumaTotal(vector) / vector.length;
    }
    
    public static int contarPares(int[] vector){
        int pares = 0;
        for(int v:vector) if(v%2==0) pares++;
        return pares;
    }
        
    public static int contarImpares(int[] vector){
        int impares = 0;
        for(int i=0; i<vector.length; i++){
            if(vector[i]%2!=0) impares++;
        }
        return impares;
    }
    
}
