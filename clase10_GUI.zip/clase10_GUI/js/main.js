/* Ejemplos de DOM */
document.getElementById('caja1').innerText = 'Hola Mundo'
document.getElementById('caja1').style = "color: red; background-color: lightblue;"

let caja2 = document.getElementById('caja2')
caja2.innerText = 'Hola a todos!!!'
caja2.style = "color: white; background-color: blue;"

let caja3 = document.getElementById('caja3')
caja3.innerHTML = '<h1>Bienvenidos a Javascript!!</h1>'
caja3.style = "text-align: center;"

const nuevaCaja = document.createElement('div')
nuevaCaja.innerText = 'Soy una nueva caja creada dinámicamente y muy feliz'
nuevaCaja.style = "color: white; background-color: purple; padding: 20px; margin: 10px;"
document.body.appendChild(nuevaCaja)