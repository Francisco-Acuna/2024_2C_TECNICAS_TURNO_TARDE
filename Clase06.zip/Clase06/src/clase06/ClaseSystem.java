

package clase06;

import java.util.Scanner;



public class ClaseSystem {
    public static void main(String[] args) {
        System.out.println("** Clase System **");
        
        /*
        La clase System es un intermediario entre la m�quina virtual de Java
        y el entorno de ejecuci�n en el que estamos ejecutando nuestro programa.
        Como la m�quina virtual de Java puede ejecutarse en m�ltiples plataformas,
        la clase System nos abstrae de la plataforma sobre la que se est� ejecutando.
        */
        
        //Los atributos m�s cl�sicos son out, err, in
        //representan streams de entrada y salida
        //son atributos finales y est�ticos
        //out es un stream de salida sincronizado
        //err es un stream de salida desincronizado
        
        /*
        Stream (flujo o corriente) es una secuencia de datos que se procesa
        o transmite de manera secuencial, en lugar de cargarse o procesarse
        en su totalidad antes de utilizarse
        */
        
        System.out.println("Hola 1");
        System.out.println("Hola 2");
        System.out.println("Hola 3");
        System.out.println("Hola 4");
        System.out.println("Hola 5");
        System.out.println("Hola 6");
        System.out.println("Hola 7");
        System.out.println("Hola 8");
        System.out.println("Hola 9");
        System.out.println("Hola 10");
        System.out.println("Hola 11");
        System.out.println("Hola 12");
        System.out.println("Hola 13");
        System.out.println("Hola 14");
        System.out.println("Hola 15");
        System.out.println("Hola 16");
        System.out.println("Hola 17");
        System.out.println("Hola 18");
        System.out.println("Hola 19");
        System.out.println("Hola 20");
        System.err.println("Ocurri� un error!");
        
        //.exit()
        //cierra el runtime, es decir, que finaliza el programa
        System.out.println("Ejecuto el m�todo .exit()");
//        System.exit(0);
//        System.out.println("Esta l�nea no se ejecuta.");
        //el par�metro 0 indica que el programa finaliz� sin errores
        //el 1 ser�a si hubieron errores
        //el -1 ser�a por advertencias
        
        //.getProperties()
        //representa un mapa o vector asociativo que es igual
        //en todas las configuraciones
        System.out.println(System.getProperties()); //propiedades del sistema
        System.out.println(System.getProperty("os.name")); //nombre del SO
        System.out.println(System.getProperty("os.version")); //versi�n del SO
        System.out.println(System.getProperty("os.arch")); //arquitectura del SO
        System.out.println(System.getProperty("java.version")); //versi�n de java
        System.out.println(System.getProperty("user.name")); //usuario del SO
        System.out.println(System.getProperty("user.home")); //directorio del usuario
        
        //Clase Scanner
        System.out.println("** Clase Scanner **");
        
        Scanner teclado = new Scanner(System.in);
        
        
        
    }
}
