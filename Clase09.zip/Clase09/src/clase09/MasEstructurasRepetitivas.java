

package clase09;


public class MasEstructurasRepetitivas {
    public static void main(String[] args) {
        
        int edad = 20;
        String mensaje;
        
        if(edad >= 18){
            mensaje = "Es mayor de edad";
        }else{
            mensaje = "No es mayor de edad";
        }
          
        System.out.println(mensaje);
        
        //Operador ternario
        mensaje = (edad>=18) ? "Es mayor de edad" : "No es mayor de edad";
        System.out.println(mensaje);
        
        //si quisi�ramos indicar un color de acuerdo al siguiente esquema:
        //1=rojo, 2=azul, 3=celeste, 4=violeta, cualquier otro n�mero=negro
        
        int nro = 1;
        if(nro == 1){
            System.out.println("rojo");
        }else if(nro == 2){
            System.out.println("azul");
        }else if(nro == 3){
            System.out.println("celeste");
        }else if(nro == 4){
            System.out.println("violeta");
        }else{
            System.out.println("negro");
        }
        
        System.out.println("\n**Estructura switch case**");
        
        switch(nro){
            case 1: System.out.println("rojo"); break;
            case 2: System.out.println("azul"); break;
            case 3: System.out.println("celeste"); break;
            case 4: System.out.println("violeta"); break;
            default: System.out.println("negro");
        }
        
        //el default no es obligatorio
        
        int dia = 7;
        
        switch(dia){
            case 1: System.out.println("El d�a es lunes"); break;
            case 2: System.out.println("El d�a es martes"); break;
            case 3: System.out.println("El d�a es mi�rcoles"); break;
            case 4: System.out.println("El d�a es jueves"); break;
            case 5: System.out.println("El d�a es viernes"); break;
            case 6: System.out.println("El d�a es s�bado"); break;
            case 7: System.out.println("El d�a es domingo"); break;
            default: System.out.println("No es un d�a v�lido.");
        }
        
        //los casos en que no hay un break ser�an como un or
        String opcion = "s";
        switch(opcion){
            case "s":
            case "S":
                System.out.println("Sale del sistema"); break;
            case "c":
            case "C":
                System.out.println("Contin�a en el sistema"); 
        }
        
        
        switch(dia){
            case 1, 2, 3, 4, 5:
                System.out.println("Es un d�a de semana."); break;
            case 6, 7:
                System.out.println("Es fin de semana!"); break;
            default:
                System.out.println("No es un d�a v�lido de semana");
        }
        
        //La estructura switch no admite expresiones de los tipos
        //float, double ni long
        
        //a partir del JDK 12
        //aparecen las expresiones switch
        //se reemplazan los : por la ->
        //se deja de utilizar el break;
        
        mensaje = switch(dia){
            case 1-> "lunes";
            case 2-> "martes";
            case 3-> "mi�rcoles";
            case 4-> "jueves";
            case 5-> "viernes";
            case 6-> "s�bado";
            case 7-> "domingo";
            default -> "d�a no v�lido";
        };
        
        System.out.println(mensaje);
        //en el switch como expresi�n debe llevar el default obligatoriamente
    }
}
