/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase12;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        /*
        Crear una aplicaci�n que valide el ingreso a una
        plataforma Online Banking a trav�s de una clave Token.
        
        Se debe tener en cuenta lo siguiente:
        * La Clave Token debe ser un n�mero aleatorio
        de 6 d�gitos.
        * El cliente debe ingresar los campos Usuario,
        Contrase�a y Clave Token (todos obligatorios).
        * El campo Usuario no distingue min�sculas
        o may�sculas.
        * El campo Contrase�a es sensible a las
        min�sculas y may�sculas.
        La clave Token aleatoria se le informa al usuario al 
        pedirle que ingrese las credenciales.        
        * El cliente solo posee 3 intentos de logueo. 
	* Si alcanza los 3 intentos fallidos de forma
        consecutiva, la aplicaci�n deber� informar al
        usuario que debe dirigirse a la sucursal del
        banco m�s cercana para poder desbloquear
        sus credenciales.
        * Por cada intento fallido, la aplicaci�n debe
        preguntar al cliente si desea continuar
        colocando las credenciales de manera correcta.
        * Si el cliente coloca las credenciales de forma
        correcta, deber� informar que ha ingresado
        correctamente al Online Banking.
        */
        
        /*
        Scanner teclado = new Scanner(System.in);
        final String USUARIO_CORRECTO = "pepito";
        final String CLAVE_CORRECTA = "1234";
        final String TOKEN_CORRECTO = "456789";

        int intentos = 3;

        do {
            System.out.println("Bienvenido a su p�gina de homebanking");
            System.out.println("Su token es: " + TOKEN_CORRECTO);
            System.out.println("Por favor ingrese su usuario: ");
            String usuario = teclado.nextLine();
            System.out.println("Por favor ingrese su clave: ");
            String clave = teclado.nextLine();
            System.out.println("Por favor ingrese su token: ");
            String token = teclado.nextLine();

            if (usuario.equalsIgnoreCase(USUARIO_CORRECTO) && clave.equals(CLAVE_CORRECTA) && token.equals(TOKEN_CORRECTO)) {
                System.out.println("Felicitaciones. Ud a ingresado correctamente a su homebanking");
                break;
            } else {
                intentos--;
                System.out.println("Los datos ingresados son incorrectos. Le quedan " + intentos + " intentos");
                if (intentos != 0) {
                    System.out.println("�Desea volver a intentar? (Ingrese \"Si\" para reintentar o \"No\" para salir)");
                    String insistir = teclado.nextLine();
                    if (insistir.equalsIgnoreCase("Si")) {
                        continue;
                    } else if (insistir.equalsIgnoreCase("No")) {
                        System.out.println("Gracias por su consulta!");
                        break;
                    }
                    break;
                }
            }

        } while (intentos > 0);
        if (intentos == 0) {
            System.out.println("Ud. ha bloqueado su usuario. Dir�jase a la sucursal "
                    + "del banco m�s cercana.");
        }
*/
       
        /*
        Scanner teclado = new Scanner(System.in);


        int token = 384800;
        String usuario = "Pepito";
        String contrase�a = "ContraCorrecta";
        int tokenIngresado;
        int intentos = 3;
        System.out.println("Bienvenido a Online Banking!.  "
                + "Recuerde que su claven Token actual es: " + token);

        do {

            do {
                System.out.println("Por favor ingrese su usuario para continuar: ");
                usuario = teclado.nextLine();
                if (usuario.equalsIgnoreCase("Pepito")) {
                    System.out.println("Usuario correcto");
                } else {
                    intentos--;
                    System.out.println("Usuario incorrecto. Usted tiene " + intentos + " intentos restantes.");
                }
                if (intentos == 0) {
                    System.out.println("Debe dirigirse a la sucursal de banco m�s cercana "
                            + "para poder desbloquearsus credenciales.");
                    System.exit(0);
                }
            } while (!usuario.equalsIgnoreCase("Pepito"));   //1er control

            do {
                System.out.println("Ingrese su contrase�a");
                contrase�a = teclado.nextLine();
                if (contrase�a.equals("ContraCorrecta")) {
                    System.out.println("Contrase�a correcta.");
                } else {
                    intentos--;
                    System.out.println("Contrase�a incorrecta. Usted tiene " + intentos + " intentos restantes.");
                }
                if (intentos == 0) {
                    System.out.println("Debe dirigirse a la sucursal de banco m�s cercana "
                            + "para poder desbloquearsus credenciales.");
                    System.exit(0);
                }
            } while (!contrase�a.equals("ContraCorrecta"));  //2do control

            do {
                System.out.println("Ingrese el codigo Token");
                tokenIngresado = teclado.nextInt();
                if (token == tokenIngresado) {
                    System.out.println("Bienvenido a su cuenta Pepito");
                    System.exit(0);
                } else {
                    intentos--;
                    System.out.println("Token incorrecto. Usted tiene " + intentos + " intentos restantes.");
                }
                if (intentos == 0) {
                    System.out.println("Debe dirigirse a la sucursal de banco m�s cercana "
                            + "para poder desbloquear sus credenciales.");
                    System.exit(0);
                }
            } while (token != tokenIngresado);  //3er control

        } while (intentos > 0);

        */
        
        
        Random random = new Random();
        Scanner teclado = new Scanner(System.in);
        int token = random.nextInt(900000) + 100000;
        String usuario = "Pepito";
        String clave = "User1234";
        String usuarioIngresado;
        String claveIngresada;
        int tokenIngresado;
        String respuesta;
        int intentos = 0;
        
        while(intentos<3){
            System.out.println("Bienvenido al On Line Banking");
            System.out.println("Su clave token es: " + token);
            
            System.out.println("Por favor, ingrese su usuario:");
            usuarioIngresado = teclado.nextLine();
            System.out.println("Ingrese su contrase�a");
            claveIngresada = teclado.nextLine();
            System.out.println("Ahora ingrese el token que le informamos:");
            tokenIngresado = teclado.nextInt(); teclado.nextLine();
            
            if(usuarioIngresado.equalsIgnoreCase(usuario) &&
                    claveIngresada.equals(clave) &&
                    tokenIngresado == token){
                System.out.println("Ha ingresado correctamente al sistema.");
                break;
            }else{
                intentos++;
                System.out.println("Credenciales incorrectas.");
                System.out.println("Intentos fallidos: " + intentos + "/3");
                
                if(intentos<3){
                    int contador = 3;
                    do{
                        System.out.println("�Desea intentar nuevamente? (si/no)");
                        respuesta = teclado.nextLine().toLowerCase();
                        if(respuesta.equals("si")){
                            break;
                        }else if(respuesta.equals("no")){
                            System.out.println("Gracias por utilizar nuestro servicio.");
                            System.out.println("Vuelva prontos");
                            System.exit(0);
                        }else{
                            contador--;
                            System.out.println("Por favor, no sea bruto y ponga \"si\" o \"no\"");
                        }
                        if(contador==0){
                            System.out.println("Se acabaron los intentos, por favor vuelva m�s tarde");
                            System.exit(0);
                        }
                    }while(!respuesta.equals("no"));
                }
            }            
        }
        
        if(intentos==3){
            System.out.println("Debe dirigirse a la sucursal del\n" +
                        "banco m�s cercana para poder desbloquear\n" +
                        "sus credenciales");
        }
        
    }
    
}
