
package clase17;

import java.util.Scanner;


public class Clase17 {

    
    public static void main(String[] args) {
        /*
        1) Una tienda ofrece un descuento del 15% sobre el total de la compra 
        durante el mes de octubre. Dado un mes y un importe, calcular cu�l es 
        la cantidad que se debe cobrar al cliente.
        */
        
        Scanner teclado = new Scanner(System.in);
        
        
//        System.out.println("Introduce el mes (del 1 al 12)");
//        int mes = teclado.nextInt();
//        System.out.print("Introduce el importe total de la compra\n$");
//        double importe = teclado.nextDouble();
//        double totalAPagar = importe;
//        double descuento = 15;
//        
//        if(mes==10){
//            totalAPagar = importe - (importe/100*descuento);
//            System.out.println("El porcentaje de descuento es %" + descuento);
//        }else{
//            totalAPagar = importe;
//        }
//        
//        
//        String totalAPagarRedondeado = String.format("%.2f", totalAPagar);
//        
//        System.out.println("El total a cobrar al cliente es: $" + totalAPagarRedondeado);
        
        /*
        2) Crear un programa que pida al usuario un n�mero y un s�mbolo, y 
        dibuje un cuadrado usando ese s�mbolo. El cuadrado tendr� el tama�o 
        que ha indicado el usuario. Por ejemplo, si el usuario introduce 4 
        como tama�o y * como s�mbolo, deber� escribirse algo como:
        ****
        ****
        ****
        ****

        */

//        System.out.println("Introduce el tama�o del cuadrado: ");
//        int tamanio = teclado.nextInt();
//        System.out.println("Introduce el s�mbolo para dibujar el cuadrado");
//        String simbolo = teclado.next();
//        
//        for(int i=0; i<tamanio; i++){
//            for(int j=0; j<tamanio; j++){
//                System.out.print(simbolo);
//            }
//            System.out.println();
//        }
         

        /*
        3) Se pide representar el algoritmo que nos calcule la suma de los 
        N primeros n�meros naturales. N se leer� por teclado. Ejemplo, si 
        ingresamos 4, hacer: 1+2+3+4 = 10
        */
        
//        int suma = 0;
//        System.out.println("Ingrese un n�mero:");
//        int numero = teclado.nextInt();
//        
//        for(int i=1; i<=numero; i++){
//            suma += i;
//        }
//        
//        System.out.println("La suma total de los n�meros naturales es: " + suma);
        
        /*
        4) Crear un programa que visualice la cuenta de los n�meros que son 
        m�ltiplos de 2 o de 3 que hay entre 1 y 100.
        */
//        int contadorDeNumerosMultiplosDe2YDe3 = 0;
//        for(int i=1; i<=100; i++){
//            if(i%3==0 || i%2==0){
//                System.out.println(i);
//                contadorDeNumerosMultiplosDe2YDe3++;
//            }
//        }
//        
//        System.out.println("La cantidad de n�meros que son m�ltiplos de 2 o de 3"
//                + " que hay entre 1 y 100 son: " 
//                + contadorDeNumerosMultiplosDe2YDe3);

        /*
        5) Desarrollar un programa que permita ingresar un n�mero N. Acto 
        seguido, permitir ingresar N n�meros. La computadora muestra cu�l 
        fue el mayor y en qu� orden apareci�. Ejemplo: Se ingresa 5, luego 
        4 8 6 7 5, la computadora muestra: "El mayor es el 8 en la 2� posici�n".
        */
        
        
//        System.out.println("Cu�ntos n�meros desea ingresar?");
//        int cantidadDeNumeros = teclado.nextInt();
//        int numeroGrande = Integer.MIN_VALUE;
//        int posicionGrande = 0;
//        for(int i=1; i<=cantidadDeNumeros; i++){
//            System.out.println("Ingrese un n�mero:");
//            int numeroNuevo = teclado.nextInt();
//            if(numeroNuevo > numeroGrande){
//                numeroGrande=numeroNuevo;
//                posicionGrande = i;
//            }
//        }
//        
//        System.out.println("El mayor n�mero es: " + numeroGrande + " en la " 
//                + posicionGrande + " posici�n.");
        
        /*
        6) Desarrollar un programa que permita ingresar un n�mero natural. La
        computadora muestra el factorial del n�mero. Ejemplo: Se ingresa 5, la
        computadora muestra: 120
        */

//        System.out.println("Por favor ingrese un n�mero natural");
//        int numeroNatural = teclado.nextInt();
//        int factorial = 1;
//        for(int i=1; i<=numeroNatural; i++){
//            factorial *= i;
//        }
//        System.out.println("El factorial del n�mero ingresado es " + factorial);

        /*
        7) Crear un algoritmo (y su correspondiente diagrama de flujo) que lea n�meros
        enteros hasta teclear 0, y nos muestre el m�ximo, el m�nimo (sin considerar el
        0) y la media (promedio) de todos ellos.
        */
        
//        int vueltas = 0;
//        int sumaTotal = 0;
//        int numeroMaximo;
//        int numeroMinimo;
//        int eleccion;
//        double promedio;
//        
//        System.out.println("Bienvenido, el sistema compara y promedia n�meros "
//                + "hasta que presiones el 0(cero)");
//        System.out.println("Digite el primer valor");
//        eleccion = teclado.nextInt();
//        numeroMaximo = eleccion;
//        numeroMinimo = eleccion;
//        
//        while(eleccion != 0){
//            vueltas++;
//            sumaTotal += eleccion;
//            System.out.println("Elija el pr�ximo valor a comparar y promediar:");
//            eleccion = teclado.nextInt();
//            if(eleccion<numeroMinimo && eleccion !=0) numeroMinimo=eleccion;
//            if(eleccion>numeroMaximo && eleccion !=0) numeroMaximo=eleccion;
//        }
//        
//        if(vueltas>0){
//            System.out.println("El n�mero m�nimo es: " + numeroMinimo);
//            System.out.println("El numero m�ximo es: " + numeroMaximo);
//            promedio = sumaTotal / vueltas;
//            System.out.println("El promedio de todos los n�meros es: " + promedio);
//        }else{
//            System.out.println("No se ingresaron n�meros v�lidos para calcular.");
//        }


        /*
        8) Leer tres n�meros que denoten una fecha (d�a, mes, a�o). 
        Comprobar que es una fecha v�lida. Si no es v�lida escribir un 
        mensaje de error. Si es v�lida escribir la fecha cambiando el 
        n�mero del mes por su nombre. Ej. si se introduce 1 2 2006, se 
        deber� imprimir ?1 de febrero de 2006?. El a�o debe ser mayor que 0
        */
        
//        System.out.println("***********");
//        System.out.println("EJERCICIO 8: Pedir tres n�meros, validarlos y mostrarlos como fecha");
//        System.out.println("***********\n");
//        
//        int numeroDia = 0, numeroMes = 0, numeroAnio = 0;
//        String mes = "";
//        
//        // Pedir n�mero para el a�o myor a 0
//        do {
//            System.out.print("Ingrese un n�mero de a�o (mayor a 0): ");
//            numeroAnio = teclado.nextInt();
//        } while (numeroAnio <= 0);
//        
//        // Verifico si es a�o bisiesto
//        boolean bisiesto = numeroAnio % 4 == 0 && numeroAnio % 100 != 0 || numeroAnio % 400 == 0;
//        
//        // Pedir n�mero para mes entre 1 y 12
//        do {
//            System.out.print("Ingrese un n�mero de mes (entre 1 y 12): ");
//            numeroMes = teclado.nextInt();
//            switch(numeroMes) {
//                case 1: mes = "enero"; break;
//                case 2: mes = "febrero"; break;
//                case 3: mes = "marzo"; break;
//                case 4: mes = "abril"; break;
//                case 5: mes = "mayo"; break;
//                case 6: mes = "junio"; break;
//                case 7: mes = "julio"; break;
//                case 8: mes = "agosto"; break;
//                case 9: mes = "septiembre"; break;
//                case 10: mes = "octubre"; break;
//                case 11: mes = "noviembre"; break;
//                case 12: mes = "diciembre"; break;
//            }
//        } while (numeroMes < 1 || numeroMes > 12);
//        
//        // Pedir n�mero para d�a entre 1 y 31
//        do {
//            System.out.print("Ingrese un n�mero de d�a (entre 1 y 31): ");
//            numeroDia = teclado.nextInt();
//            
//            // Valido d�as de febrero para a�o bisiesto
//            if(bisiesto && numeroDia > 29 && numeroMes == 2) {
//                System.out.println("En a�os bisiestos el mes de febrero tiene "
//                        + "hasta 29 d�as y ha ingresado " + numeroDia + ". "
//                                + "Por favor, vuelva a ingresar un n�mero de d�a.");
//                numeroDia = 0;
//                continue;
//            }
//            
//            // Valido d�as de febrero para a�o no bisiesto
//            if(!bisiesto && numeroDia > 28 && numeroMes == 2) {
//                System.out.println("En a�os no bisiestos el mes de febrero tiene "
//                        + "hasta 28 d�as y ha ingresado " + numeroDia + ". "
//                                + "Por favor, vuelva a ingresar un n�mero de d�a.");
//                numeroDia = 0;
//                continue;
//            }
//            
//            // Valido meses que terminan en 30
//            if(numeroMes == 4 || numeroMes == 6 ||
//               numeroMes == 9 || numeroMes == 11 && 
//               numeroDia > 30) {
//                System.out.println("El mes " + mes + " tiene hasta 30 d�as. Por favor, vuelva a ingresar un n�mero de d�a.");
//                numeroDia = 0;
//                continue;
//            }        
//        } while (numeroDia < 1 || numeroDia > 31);
//        System.out.println("Ha ingresado la siguiengte fecha: " + numeroDia + " de " + mes + " de " + numeroAnio);

        /*
        9) Imprimir la siguiente figura utilizando la estructura for:
            @@@@
        */
        
//        for(int i=1; i<5; i++) System.out.print("@");

        /*
        10) Imprimir la siguiente figura utilizando la estructura for:
        @@
        @
        @@
        @ 
        @

        */
        
//        for(int i=1; i<=5; i++){
//            if(i==1 || i==3){
//                System.out.println("@@");
//            }else{
//                System.out.println("@");
//            }
//        }

        /*
        11) Imprimir la siguiente figura utilizando la estructura for:
            @@
            @
            @@@
            @@@@
            @@@@@
        */
        
//        for (int i = 1; i <= 5; i++) {
//            if(i==1) System.out.println("@@");
//            else if(i==2) System.out.println("@");
//            else {
//                for(int j=1; j<=i; j++){
//                    System.out.print("@");
//                }
//                System.out.println("");
//            }
//        }


        /*
        12) Imprimir la siguiente figura utilizando la estructura for:
            @@@@@
            @@@@
            @@@
            @@
            @

        */
        
//        for (int i = 5; i >= 1; i--){
//            for (int j = 1; j <= i; j++) {
//                System.out.print("@");
//            }
//            System.out.println("");
//        }

        /*
        13) Imprimir la siguiente figura utilizando la estructura for:
            @@
            @@@@
            @@@@
            @@@
            @@
            @
        */
        
//        for(int i=1; i<=6; i++){
//            int cantidad = i;
//            switch(cantidad){
//                case 1,5: System.out.println("@@"); break;
//                case 2,3: System.out.println("@@@@"); break;
//                case 4: System.out.println("@@@"); break;
//                default: System.out.println("@"); break;
//            }
//        }
        
        
        /*
        14) Imprimir la siguiente figura utilizando la estructura for:
            @@@@@
            @@@
            @@
            @@
            @@@@@
        */
        
        for (int i = 1; i < 6; i++) {
            int cantidad = i;
            switch(cantidad){
                case 1,5: System.out.println("@@@@@"); break;
                case 2: System.out.println("@@@"); break;
                default: System.out.println("@@"); break;
            }
        }

    }
    
}
