

package clase05;


public class ClaseString {
    public static void main(String[] args) {
        /*
        Convenciones de escritura
        camel case -> estaEsUnaFraseEnCamelCase (lower camel case)
        pascal case -> EstaEsUnaFraseEnCamelCase (upper camel case)
        snake_case -> esta_es_una_frase_en_snake_case
        */
        
        System.out.println("Clase String");
        //la clase String contiene un vector de caracteres
        
        //podemos crear un objeto de la clase String de varias maneras
        String texto1 = "Cadena de Texto!";
        String texto2 = new String("hola");
        String texto3 = "hola";
        
        //m�todos para comparar
        System.out.println(texto3 == "hola"); //true
        System.out.println(texto2 == "hola"); //false
        //el operador de comparaci�n == compara que sean el mismo espacio
        //en memoria.
        
        //para poder comparar cadenas de caracteres teniendo en cuenta
        //su contenido, se utilizan los m�todos .equals() .equalsIgnoreCase()
        System.out.println(texto2.equals("hola")); //true
        System.out.println(texto3.equals("hola")); //true
        System.out.println(texto2.equals(texto3)); //true
        System.out.println(texto2.equals("Hola")); //false
        //para ignorar las may�sculas y min�sculas
        //utilizamos .equalsIgnoreCase()
        System.out.println(texto2.equalsIgnoreCase("Hola")); //true
        
        //.contains()
        //devuelve un booleano indicando si la cadena, contiene la
        //subcadena dada
        System.out.println(texto1.contains("hola")); //false
        System.out.println(texto2.contains("ol")); //true
        System.out.println(texto2.contains("lo")); //false
        
        //.length()
        //devuelve un n�mero entero que representa la longitud del vector
        //es decir, cu�ntos caracteres tiene la cadena
        System.out.println(texto1.length()); //16
        System.out.println(texto2.length()); //4
        
        //.isEmpty()
        //devuelve un booleano indicando si la cadena est� vac�a
        //es decir, si su longitud es igual a 0
        System.out.println(texto1.isEmpty()); //falso
        
        //.isBlank() aparece a partir del JDK 11
        //devuelve un booleano que indica si la cadena est� vac�a
        //o si solo contiene espacios en blanco, o si solo contiene
        //saltos de l�nea o tabulaciones.
        String texto4 = "   ";
        System.out.println(texto4.isEmpty()); //false
        System.out.println(texto4.isBlank()); //true
        
        //.charAt()
        //devuelve el caracter del �ndice dado
        System.out.println(texto1.charAt(7)); //d
        System.out.println(texto2.charAt(2)); //l
        //System.out.println(texto2.charAt(5)); //l
        //la anterior sentencia arroja error porque no existe
        //la posici�n 5 para un vector de longitud 4
        
        //.indexOf()
        //devuelve el �ndice de la primera ocurrencia de la subcadena
        //si no la encuentra, devuelve -1
        System.out.println(texto1.indexOf("texto")); //-1 
        // porque la t es may�scula en texto1
        System.out.println(texto1.indexOf("e")); //
        
    }
}
