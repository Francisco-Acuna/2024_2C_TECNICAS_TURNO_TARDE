
package clase05;

import java.text.DecimalFormat;


public class Clase05 {


    public static void main(String[] args) {
        /*
        1-
        Dados num1=5, num2=10 y num3=20. Informar:
        a) num1+num2
        b) num3-num1
        c) num1*num3
        d) num3/num2
        */
        
        int num1 = 5;
        int num2 = 10;
        int num3 = 20;
        //int num1=5, num2=10, num3=20;
        
        System.out.println("El resultado de num1 + num2 es: " + (num1 + num2));
        System.out.println("El resultado de num3 - num2 es: " + (num3 - num1));
        System.out.println("El resultado de num1 * num3 es: " + (num1 * num3));
        System.out.println("El resultado de num3 / num2 es: " + (num3 / num2));
        
        System.out.println("");
        System.out.println("*********************");
        System.out.println("");
        
        /*
        2-
        Dados nro1=10, nro2=20 y nro3=30. Informar :
        a) El total de la suma de todas las variables
        b) El promedio
        c) El resto entre nro2 y nro1
        */
        
        int nro_1 = 10;
        int nro_2 = 20;
        int nro_3 = 30;
        
        int sumaTotal = nro_1 + nro_2 + nro_3;
        int promedio = sumaTotal / 3;
        int resto = nro_2 % nro_1;
        
        System.out.println("El total de la suma de todas las variables "
                + "es igual a " + sumaTotal );
        System.out.println("El promedio es de " + promedio);
        System.out.println("El resto entre entre nro_2 y nro_1 es de " + resto);
        
        System.out.println("");
        System.out.println("*********************");
        System.out.println("");
        
        /*
        3-
        Declarar dos variables n1=5 y n2=10.
        Utilizando concatenaci�n entre las variables y los literales, 
        mostrar en pantalla la siguiente expresi�n:
        n1 es igual a 5, n2 es igual a 10 y n1 m�s n2 es igual a 15.
        */
        
        int n1=5, n2=10;
        
        int resultadoSuma=n1+n2;
        
        System.out.println("n1 es igual a " + n1 + ", n2 es igual a " + n2 +
                " y n1 m�s n2 es igual a " + resultadoSuma + ".");
        
        System.out.println("");
        System.out.println("*********************");
        System.out.println("");
        
        /*
        4-
        Haciendo uso de la constante IVA=21, calcular el precio con IVA de 
        los siguientes productos e informar:
        a) remera:$59.90
        b) pantal�n:$99.90
        c) campera:$149.90
        */
        
        final float IVA = 21;
        float remera = 59.90f;
        float pantalon = 99.90f;
        float campera = 149.90f;
        
        System.out.println("El precio final de la remera con IVA es " +
                ((remera / 100 * IVA) + remera));
        System.out.println("El precio final de la pantalon con IVA es " +
                ((pantalon / 100 * IVA) + pantalon));
        System.out.println("El precio final de la campera con IVA es " +
                ((campera / 100 * IVA) + campera));
        
        DecimalFormat df = new DecimalFormat("#.##");
        float remeraConIVA = (remera / 100 * IVA) + remera;
        System.out.println(remeraConIVA);
        String precioRedondeado = df.format(remeraConIVA);
        System.out.println("$" + precioRedondeado);
        
    }
    
}
