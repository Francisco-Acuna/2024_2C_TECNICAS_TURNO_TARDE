/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase04;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase04 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        // CONSTANTES
        
        /*
        Las constantes son similares a las variables.
        Representan un espacio en memoria, tienen un identificador
        y almacenan un valor con un tipo de dato asociado.
        Pero la diferencia principal es que, a diferencia de las
        variables, las constantes no pueden cambiar su valor.
        Deben llevar la palabra reservada final
        */
        
        final double PI = 3.14;
        //por convenci�n los nombres de constantes, van con may�scula
//        PI = 3.15; error, no se puede cambiar el valor

        // concatenaci�n
        // operador +
        String nombre = "Marcelo";
        String apellido = "Gonzalez";
        System.out.println(nombre);
        System.out.println(apellido);
        System.out.println(nombre + apellido);
        System.out.println(nombre + " " + apellido);
        System.out.println("Su nombre es: " + nombre + " " + apellido);
        
        String texto = "este es un texto";
        String texto2 = "OTRO TEXTO";
        System.out.println(texto.toUpperCase());
        System.out.println(texto2.toLowerCase());
        
        /*
        ###################
            OPERADORES 
        ###################
        */
        
        // Operadores aritm�ticos
        /*
        + suma
        - resta
        * multiplicaci�n
        / divisi�n
        % m�dulo o resto de la divisi�n
        Son operadores binarios, porque necesitan de 2 operandos.
        Los operandos son num�ricos y el resultado es num�rico.
        */
        
        int nro1 = 10;
        int nro2 = 2;
        
        System.out.print("Suma: ");
        System.out.println(nro1 + nro2);
        
        System.out.print("Resta: ");
        System.out.println(nro1 - nro2);
        
        System.out.print("Multiplicaci�n: ");
        System.out.println(nro1 * nro2);
        
        System.out.print("Divisi�n: ");
        System.out.println(nro1 / nro2);
        
        System.out.print("M�dulo o resto: ");
        System.out.println(nro1 % nro2);
        
        
        //Operadores de asignaci�n
        /*
        =   asignaci�n
        +=  suma y asignaci�n
        -=  resta y asignaci�n
        *= multiplicaci�n y asignaci�n
        /= divisi�n y asignaci�n
        %= m�dulo y asignaci�n
        Son operadores binarios.
        Asignan el valor a una variable y se la modifican utilizando una expresi�n.
        */
        
        System.out.println(nro1); //10
        System.out.println(nro1 += 2);
        System.out.println(nro1); //12
        System.out.println(nro1 -= 2);//10
        System.out.println(nro1 *= 2);//20        
        System.out.println(nro1 /= 2);//10        
        System.out.println(nro1 %= 2);//0

        // Operadores incrementales y decrementales
        /*
        ++  incrementa el valor de la variable en 1
        --  decrementa el valor de la variable en 1
        Son operadores unarios, trabajan con un solo operando.
        */
        
        System.out.println(nro1); //0
        nro1 ++; //incrementa en 1 el valor de la variable
        System.out.println(nro1); //1
        //nro1 ++;
        //nro1 = nro1 + 1;
        //nro1 += 1;
        nro1 --; //decrementar en 1 el valor de la variable
        System.out.println(nro1); //0       

        // Operadores relacionales
        /*
        >   mayor
        <   menor
        >=  mayor o igual
        <=  menor o igual
        ==  igual
        !=  distinto
        Son operadores binarios.
        Los operandos son num�ricos, pero el resultado es booleano.
        */
        
        nro1 = 15;
        nro2 = 20;
        
        System.out.println(nro1 > nro2); //falso
        System.out.println(nro1 < nro2); //verdadero
        System.out.println(nro1 <= nro2); //verdadero
        System.out.println(nro1 >= nro2); //falso
        System.out.println(nro1 == nro2); //falso
        System.out.println(nro1 != nro2); //verdadero
        
        
        //Tabla de verdad
        //es una representaci�n l�gica de resultados
        /*
        A   B   AND OR
        V   V   V   V
        V   F   F   V
        F   V   F   V
        F   F   F   F
        
        Negaci�n (NOT)
        A   NOT
        V   F
        F   V     
        */
        
        //Operadores l�gicos
        /*
        &   AND
        |   OR
        !   NOT
        Los operandos son booleanos.
        El resultado es booleano.
        */
        
        boolean log1 = true;
        boolean log2 = false;
        
        /*
        Un solo operador l�gico & o | eval�a ambas condiciones.
        Al utilizar 2 operadores && || si con la primera condici�n
        determina el valor de verdad, ya no eval�a la segunda.
        */
        
        System.out.print("AND &&:");
        System.out.println(log1 && log2); //false
        
        System.out.print("OR ||:");
        System.out.println(log1 || log2); //true
        
        System.out.print("NOT:");
        System.out.println(!log1); //false
        System.out.print("NOT:");
        System.out.println(!log2); //true      
        
    }
    
}
